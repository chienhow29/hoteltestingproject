package utar.edu.my;


public class Printer {

	
	
	
	public void printInfo(String name, String member_type, String room_type)
	{
		System.out.println("Welcome back " + name);
		System.out.println("You are currently a " + member_type + " user");
	}
}
